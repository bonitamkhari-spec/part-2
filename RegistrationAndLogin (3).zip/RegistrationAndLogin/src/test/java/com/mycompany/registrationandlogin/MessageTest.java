/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registrationandlogin;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ntsako
 */
public class MessageTest {
    
    @Test
    public void testMessageLengthValid() {
        Message msg = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue(msg.checkMessageLength());
        assertEquals("Message ready to send.", msg.checkMessageLengthStatus());
    }

    @Test
    public void testMessageLengthInvalid() {
        String longText = "A".repeat(260);
        Message msg = new Message(1, "+27718693002", longText);
        assertFalse(msg.checkMessageLength());
        assertTrue(msg.checkMessageLengthStatus().contains("Message exceeds 250 characters"));
    }

    @Test
    public void testCheckRecipientCellValid() {
        Message msg = new Message(1, "+27718693002", "Test message");
        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCellInvalid() {
        Message msg = new Message(1, "08575975889", "Test message");
        assertFalse(msg.checkRecipientCell());
    }

    @Test
    public void testCreateMessageHash() {
        Message msg = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String hash = msg.createMessageHash();
        assertNotNull(hash);
        assertTrue(hash.contains(":1:HIGHTONIGHT") || hash.contains(":1:HI"));
    }
    
}
