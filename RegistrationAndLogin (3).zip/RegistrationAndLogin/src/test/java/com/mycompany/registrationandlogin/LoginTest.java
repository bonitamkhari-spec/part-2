/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registrationandlogin;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ntsako
 */
public class LoginTest {
    
   
    @Test
    public void testCheckUserNameValid() {
        
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertTrue(login.checkUserName());
    }
    
    @Test
    public void testCheckUserNameInvalid() {
        
        Login login = new Login(
                "kyle!!!!!!",
                "Ch&cK@ke99!",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertFalse(login.checkUserName());
    }
                   
    @Test
    public void testCheckPasswordComplexityValid() {
        
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        
        Login login = new Login(
                "kyl_1",
                "risima",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertFalse(login.checkPasswordComplexity());
        
    }

    @Test
    public void testCheckCellPhoneNumberValid() {
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+2709999",
                "Ntsako",
                "Mkhari");
        assertFalse(login.checkCellPhoneNumber());
    }

    @Test
    public void testLoginSuccessful() {
        
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976",
                "Ntsako",
                "Mkhari");
        assertTrue(login.loginUser("kyl_1", "Ch&cK@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        
        Login login = new Login(
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976",
                "Risima",
                "Mkhari");
        assertFalse(login.loginUser("wrong_username", "wrong_Password"));
    }

   
}
