/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrationandlogin;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;


/**
 *
 * @author Ntsako
 */

public class Message {
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private String status;

    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
        this.status = "Pending";
    }

    // Helper to generate initial 10-digit ID
    private String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + rand.nextLong(9000000000L);
        return String.valueOf(id);
    }

    //check Message ID
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // check Recipient Cell()
    public boolean checkRecipientCell() {
        return recipient != null && recipient.length() <= 13 && recipient.matches("\\+\\d{10,13}");
    }

    // create Message Hash
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2) {
            return "";
        }
        String firstTwoDigits = messageID.substring(0, 2);
        
        String cleanText = messageText != null ? messageText.trim() : "";
        String firstWord = "";
        String lastWord = "";
        
        if (!cleanText.isEmpty()) {
            String[] words = cleanText.split("\\s+");
            firstWord = words[0].replaceAll("[^a-zA-Z]", "").toUpperCase();
            if (words.length > 1) {
                lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "").toUpperCase();
            } else {
                lastWord = firstWord;
            }
        }
        
        return firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord;
    }

    // Check message length
    public boolean checkMessageLength() {
        return messageText != null && messageText.length() < 250;
    }

    //SentMessage(): Allows user to choose if they want to send, store, or disregard the message
    public String SentMessage(int choice) {
        if (choice == 1) {
            this.status = "Sent";
            return "Message successfully sent";
        } else if (choice == 2) {
            this.status = "Disregarded/Deleted";
            return "Press 0 to delete the message";
        } else if (choice == 3) {
            this.status = "Stored";
            return "Message successfully stored";
        } else {
            return "Invalid option.";
        }
    }

    // print Messages
    public String printMessages() {
        return "\n--- Message Details ---\n" +
               "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + messageText + "\n" +
               "Status: " + status;
    }

    // returnTotalMessagess()
    public static int returnTotalMessagess(int sentCount) {
        return sentCount;
    }

    // store Message
    public void storeMessage() {
        this.status = "Stored";
                try (FileWriter file = new FileWriter("messages.json", true)) {
            String jsonEntry = "{\n" +
                    "  \"messageID\": \"" + messageID + "\",\n" +
                    "  \"messageNumber\": " + messageNumber + ",\n" +
                    "  \"recipient\": \"" + recipient + "\",\n" +
                    "  \"messageText\": \"" + messageText + "\",\n" +
                    "  \"messageHash\": \"" + messageHash + "\",\n" +
                    "  \"status\": \"" + status + "\"\n" +
                    "},\n";
            file.write(jsonEntry);
            System.out.println("Message successfully stored.");
        } catch (IOException e) {
            System.out.println("An error occurred while storing the message: " + e.getMessage());
        }
    }
  

    // Getters and Setters
    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    boolean checkRecipient() {
        return recipient != null && recipient.matches("\\+\\d{10,13}");
    }

    public String checkMessageLengthStatus() {
        if (messageText != null && messageText.length()< 250){
            return "Message ready to send.";
        } else{
            int excess = messageText !=null ? messageText.length()- 250 : 0;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size. ";
        }
    }

}
