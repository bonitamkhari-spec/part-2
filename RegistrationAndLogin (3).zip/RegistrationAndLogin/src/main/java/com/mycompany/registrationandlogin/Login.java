/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrationandlogin;

/**
 *
 * @author Ntsako
 */
class Login {
    
    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;
    private boolean LoginStatus;

    // Constructor
    public Login(String username, String password, String cellPhoneNumber,
                 String firstName, String lastName) {
        
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.lastName = lastName;
        this.firstName = firstName;
        this.LoginStatus = false;
    }

    // Check username
    public boolean checkUserName() {

        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    // Check cellphone number
    public boolean checkCellPhoneNumber() {

        String cellPhoneRegex = "\\+27\\d{9}";

        if (cellPhoneNumber.matches(cellPhoneRegex)) {
            return true;
        } else {
            return false;
        }
    }

    // Check password
    boolean checkPasswordComplexity() {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                hasCapital = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }

        if (password.length() >= 8
                && hasCapital
                && hasNumber
                && hasSpecialCharacter) {

            return true;

        } else {
            return false;
        }
    }

    // Register user
    public String registerUser() {

        if (checkUserName()) {
            System.out.println("Username successfully captured.");
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (checkPasswordComplexity()) {
            System.out.println("Password successfully captured.");
        } else {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (checkCellPhoneNumber()) {
            System.out.println("Cell phone number successfully captured.");
        } else {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        return "User successfully registered.";
    }

    // Login user
    public boolean loginUser(String enteredUserName, String enteredPassword) {

        if (enteredUserName.equals(username)
                && enteredPassword.equals(password)) {

            LoginStatus = true;

        } else {

            LoginStatus = false;
        }

        return LoginStatus;
    }

    // Return login status
    public String returnLoginStatus() {

        if (LoginStatus) {

            return "Login successful\nWelcome "
                    + firstName + " " + lastName
                    + ", it is great to see you again.";

        } else {

            return "Login has failed\nUsername or password is incorrect, please try again.";
        }
    }
}


