/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin;

import java.util.Scanner;

/**
 *
 * @author Ntsako
 */
public class RegistrationAndLogin { 

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("registration");
        System.out.println("Enter your username:");
        String username = input.nextLine();
        System.out.println("Enter your password:");
        String password = input.nextLine();
        System.out.println("Enter your cell phone number:");
        String cellPhoneNumber = input.nextLine();
        System.out.println("Enter your first name:");
        String firstName = input.nextLine();
        System.out.println("Enter your last name:");
        String lastName = input.nextLine();
       
        Login login = new Login(username, password, cellPhoneNumber, firstName, lastName);
        String registrationResult = login.registerUser();
        System.out.println(registrationResult);
        
        if (registrationResult.equals("User successfully registered.")) {
            boolean loggedIn = false;
            
            // loop for login until successful
            while (!loggedIn) {
                System.out.println("\n--- LOGIN ---");
                System.out.print("Enter your username to login: ");
                String loginUsername = input.nextLine();
                System.out.print("Enter your password to login: ");
                String loginPassword = input.nextLine();
                
                loggedIn = login.loginUser(loginUsername, loginPassword);
                System.out.println(login.returnLoginStatus());
            }
            
            // main Quickchat welcome message
            System.out.println("\nWelcome to QuickChat.");
            
            boolean running = true;
            
            // main QuickChat Menu Loop
            while (running) {
                System.out.println("\n--- QuickChat Menu ---");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.print("Choose an option (1-3): ");
                
                String choiceStr = input.nextLine();
                int choice;
                try {
                    choice = Integer.parseInt(choiceStr);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number between 1 and 3.");
                    continue;
                }
                
                switch (choice) {
                    case 1:
                        System.out.print("How many messages do you wish to enter? ");
                        int numMessages;
                        try {
                            numMessages = Integer.parseInt(input.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid number. Returning to menu.");
                            break;
                        }
                        
                        int totalSentMessagesCount = 0;
                        
                        for (int i = 1; i <= numMessages; i++) {
                            System.out.println("\n--- Entering Message " + i + " of " + numMessages + " ---");
                            
                            System.out.print("Enter recipient cell phone number (with international code, e.g., +27...): ");
                            String recipient = input.nextLine();
                            
                            System.out.print("Enter your message: ");
                            String text = input.nextLine();
                            
                            Message msg = new Message(i, recipient, text);
                           
                            if (!msg.checkMessageLength()) {
                                System.out.println("Please enter a message of less than 250 characters.");
                                i--; 
                                continue;
                            }
                            
                            if (!msg.checkRecipient()) {
                                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                                i--;
                                continue;
                            }
                            
                            System.out.println("Message Hash: " + msg.getMessageHash());
                            
                            System.out.println("\nChoose an option:");
                            System.out.println("1) Send Message");
                            System.out.println("2) Disregard Message");
                            System.out.println("3) Store Message to send later");
                            System.out.print("Enter option (1-3): ");
                            
                            int postChoice;
                            try {
                                postChoice = Integer.parseInt(input.nextLine());
                            } catch (NumberFormatException e) {
                                postChoice = 1;
                            }
                            
                            if (postChoice == 1) {
                                msg.setStatus("Sent");
                                totalSentMessagesCount++;
                                System.out.println("Message successfully sent");
                                
                                System.out.println("\n--- Sent Message Details ---");
                                System.out.println("Message ID: " + msg.getMessageID());
                                System.out.println("Message Hash: " + msg.getMessageHash());
                                System.out.println("Recipient: " + msg.getRecipient());
                                System.out.println("Message: " + msg.getMessageText());
                                
                            } else if (postChoice == 2) {
                                System.out.print("Press 0 to delete the message: ");
                                String deleteConfirm = input.nextLine();
                                if (deleteConfirm.equals("0")) {
                                    msg.setStatus("Deleted");
                                    System.out.println("Message successfully deleted.");
                                } else {
                                    System.out.println("Deletion cancelled.");
                                }
                            } else if (postChoice == 3) {
                                msg.setStatus("Stored");
                                System.out.println("Message successfully stored");
                            } else {
                                System.out.println("Invalid option.");
                            }
                        }
                        
                        System.out.println("\nTotal messages successfully sent in this session: " + totalSentMessagesCount);
                        break;
                        
                    case 2:
                        System.out.println("Coming Soon.");
                        break;
                        
                    case 3:
                        System.out.println("Exiting QuickChat. Goodbye!");
                        running = false;
                        break;
                        
                    default:
                        System.out.println("Invalid choice. Please select 1, 2, or 3.");
                        break;
                }
            }
        } else {
            System.out.println("Registration failed. Application exiting.");
        }
        
        input.close();
    }
}